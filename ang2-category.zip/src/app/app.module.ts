//https://github.com/cornflourblue/angular2-registration-login-example/blob/master/app/_services/user.service.ts
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { Http,	HttpModule ,  Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { FormsModule }    from '@angular/forms';
import { routing }  from './app.routing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header.component';
import { HomeComponent } from './home/home.component';
import { CategoryComponent } from './category/category.component';
import { PageNotFoundComponent } from './notfound.component';

import { CategoryService } from './_services/category.service'
 





@NgModule({
  declarations: [
    AppComponent,
	HeaderComponent,
	HomeComponent,
	CategoryComponent,
	PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
	BrowserAnimationsModule,
	HttpModule,
	HttpClientModule,
	FormsModule,
	routing
  ],
  providers: [CategoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
