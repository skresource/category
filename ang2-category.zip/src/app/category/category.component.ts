import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Router  } from '@angular/router';
import { CategoryService } from '../_services/category.service';
import { Categories } from '../_models/categories'

@Component({
  selector: 'category',
  templateUrl: 'category.component.html',
  //styleUrls: ['./app.component.css']
})


export class CategoryComponent {
	categories: Categories[] = [];
	isLoaded: boolean = false;
	constructor(
		private route: ActivatedRoute, 
		private router: Router,
		private categoryService: CategoryService,
	){ }
	
	ngOnInit() {
		/*this.categoryService.getByCategory()
            .subscribe(
                data => {
					console.log('data fetched');
					//this.categories = data; 
                },
                error => {                     
					console.log(error)                     
                },
				() => {}
			)*/
	}
	
}