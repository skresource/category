export class Categories {
	id: number;
	parent: number;
	name: string;
	desc: string;
}