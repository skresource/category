//https://www.concretepage.com/angular-2/angular-2-routing-and-navigation-example
import { Routes, RouterModule } from '@angular/router';

 
 
 
import { HomeComponent } from './home/home.component';
import { CategoryComponent } from './category/category.component';
import { PageNotFoundComponent } from './notfound.component';
 

const appRoutes: Routes = [
    
    
	{ path: '', redirectTo: 'home', pathMatch: 'full'}, //default 	
	 
	{ path: 'home', component: HomeComponent },  
	{ path: 'category/:id', component: CategoryComponent }, //path=register or login 	
	/*{ path: 'dashboard/dashboard', component: DashBoardComponent }, //path=register or login 
	{ path: 'profile/edit/:id', component: ProfileComponent },  
	{ path: '**', component: PageNotFoundComponent } */
];

export const routing = RouterModule.forRoot(appRoutes);