import { Injectable } from '@angular/core';
import { HttpClient,  HttpClientModule  } from '@angular/common/http';
import { Http,	HttpModule ,  Response } from '@angular/http';

import { Categories } from '../_models/categories';

@Injectable()
export class CategoryService {
	
	constructor(private http: HttpClient){}
	
	/*create(user: User) {
		return this.http.post('http://localhost:3000/employees', user);
	}*/
	
	getAllCategory() {
        return this.http.get<Categories[]>('http://localhost:3000/categories/?parent=0');
    }
	
	/*delete(id: number) {
        return this.http.delete('http://localhost:3000/employees/' + id);
    }
	
	getUser(id: number) {		
        return this.http.get('http://localhost:3000/employees/' + id);
    }
	
	updateUser(id: number, user: User) {		
        return this.http.put('http://localhost:3000/employees/' + id, user);
    }*/
}