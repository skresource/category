//https://www.concretepage.com/angular-2/angular-2-routing-and-navigation-example
import { Routes, RouterModule } from '@angular/router';

 
 
 
import { HomeComponent } from './home/home.component';
import { CategoryComponent } from './category/category.component';
import { CategorydetailsComponent } from './category/categorydetails.component';

import { PageNotFoundComponent } from './notfound.component';
 

const appRoutes: Routes = [
    
    
	{ path: '', redirectTo: 'home', pathMatch: 'full'}, //default 	
	 
	{ path: 'home', component: HomeComponent },  
	{ path: 'category/parent/:id', component: CategoryComponent },  
	{ path: 'image-details/:id', component: CategorydetailsComponent },  
	//{ path: '**', component: PageNotFoundComponent } 
];

export const routing = RouterModule.forRoot(appRoutes);