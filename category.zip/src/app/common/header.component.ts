import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Router  } from '@angular/router';

@Component({
	selector: 'common-header',
	templateUrl: "header.component.html"
})


export class HeaderComponent{}
