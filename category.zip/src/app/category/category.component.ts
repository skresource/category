import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Router,Params } from '@angular/router';
import { CategoryService } from '../_services/category.service';
import { Categories } from '../_models/categories'

@Component({
  selector: 'category',
  templateUrl: 'category.component.html',
  //styleUrls: ['./app.component.css']
})


export class CategoryComponent {
	subCategories: any = [];
	isLoaded: boolean = false;
	imageDetail: any;
	constructor(
		private route: ActivatedRoute, 
		private router: Router,
		private categoryService: CategoryService,
	){ }
	
	ngOnInit() { 
	
		this.route.params.subscribe((params: Params) => {
			let parentId = params['id'];			 
			this.categoryService.getAllSubCategory(parentId)
            .subscribe(
                data => { 
					this.subCategories = data; 
                },
                error => {                     
					console.log(error)                     
                }				 
			) 
		}); 
		 
	}	 
	 
	 
	showContactDetails(id){ 
		this.categoryService.getDetails(id) 
		.subscribe(
			data  => {
				this.imageDetail = data;
				alert(this.imageDetail.desc);
			},
			error  => {
				console.log(error)
			} 
		)
	}
	
}