import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Router,Params } from '@angular/router';
import { CategoryService } from '../_services/category.service';
import { Categories } from '../_models/categories'

@Component({
	selector: 'category-details',
	templateUrl: 'categorydetails.component.html'
})

export class CategorydetailsComponent {
	
	imageDetails: any;
	id: number;
	isLoaded: boolean = false;
	radioOptions: any;
	selectedValue: string;
	info:string = "0";
	
	
	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private categoryService: CategoryService		 
	){}
	
	ngOnInit(){
		
		this.route.params.subscribe((params: Params) => {
			this.id = params['id'];
			
			this.categoryService.getDetails(this.id)				 
				.subscribe(
					data => {
						this.imageDetails = data;						
						this.isLoaded= true;
						this.radioOptions = this.imageDetails.options[0];
						 
					},
					error  => {
						console.log(error);
					}
				)
		})
		
		//this.categoryService.getDetails()
	}
	
	
	selectedAddons(selectedOption: string){
		this.selectedValue = selectedOption;
		alert(this.selectedValue)
	}
	
	addToCart(imgDetailObj:any){
		let reqArray = {"image_name":imgDetailObj.name,"option_selected":this.radioOptions}
		this.categoryService.addCartRequest(reqArray)
		.subscribe(
			data =>{
				console.log(data);
				alert("Product added to cart\nName: "+data.image_name + "\nOption selected:"+data.option_selected);
				this.radioOptions = this.imageDetails.options[0];
				//this.info = "Name: "+data.image_name + "\nOption selected:"+data.option_selected;
				
			},
			error =>{
				console.log(error);
			}
		)
	}
	
}