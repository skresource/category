import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Router  } from '@angular/router';
import { CategoryService } from '../_services/category.service';
import { Categories } from '../_models/categories'

@Component({
  selector: 'home',
  templateUrl: 'home.component.html',
  //styleUrls: ['./app.component.css']
})


export class HomeComponent {
	categories: Categories[] = [];
	isLoaded: boolean = false;
	constructor(
		private route: ActivatedRoute, 
		private router: Router,
		private categoryService: CategoryService,
	){ }
	
	ngOnInit() {
		this.categoryService.getAllCategory()
            .subscribe(
                data => { 
					this.categories = data; 
                },
                error => {                     
					console.log(error)                     
                },
				() => {}
			);
	}
	
}